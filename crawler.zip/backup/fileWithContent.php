<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of readFile
 *
 * @author SukL
 */
class fileWithContent {
    
    private $fileName;
    private $fileContent;
    
    public function setFilePath($inFileName){
        
        $this->fileName = $inFileName;
        
    }
    
    
}
