<?php
namespace App\Search;

use App\Model;
use Tracy\Debugger;

/**
 * Description of searchClass
 *
 * @author SukL
 */
class searchClass {
    //put your code here
}
