<?php

namespace App\Crawler;

use Nette;
use App\Crawler;
use Tracy\Debugger;
use App\Model\crawlerModel;
use Nette\Utils\DateTime;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of crawler
 *
 * @author SukL
 */
class crawlerClass{

    private $startPath;
    private $ignoreArray = array('.', '..');
    private $returnContent = array();
    private $keywordModel;
    private $numOfDirs = 0;
    private $numOfFiles = 0;
    private $startTime = null;
    private $endTime;
    private $level = 0;
    private $domain;
    private $reindex = false;
    
    
    public function __construct($startPath, crawlerModel $keywordModel,$reindex = false) {
	$this->keywordModel = $keywordModel;
	$this->startPath = $startPath;
	$this->reindex = $reindex;
	
    }

    public function getStartPath() {
	return $this->startPath;
    }

    public function startCrawler() {
	
	if ($this->startTime === null) {
	    $this->startTime = new DateTime();
	}
	if (is_Dir($this->startPath)) {

	    $this->domain = new domainClass($this->startPath, "jablonec", $this->keywordModel);
	    $this->domain->checkDeadLinks();
	    $this->crawl($this->startPath);
	}
	
	$this->endTime = new DateTime();
    }

    private function crawl($path) {
	$this->level++;
	$dirHandler = opendir($path);
	if ($dirHandler !== false) {

	    while ((($file = readdir($dirHandler)) !== false) && file_exists($path)) {
		if (!in_array($file, $this->ignoreArray)) {

		    if (is_Dir($path . "\\" . $file)) {
			$this->numOfDirs++;
			$dirClass = new directoryClass($path . "\\" . $file, $this->level, $this->domain, $this->keywordModel);
			$this->crawl($path . "\\" . $file);
			//Debugger::dump($indexClass);
		    } else {
			$this->numOfFiles++;
			$fileClass = new fileClass($path . "\\" . $file, $this->level, $this->domain, $this->keywordModel);
			//Debugger::dump($fileClass);
		    }
		}
	    }
	} else {
	    //directory not found
	}
	$this->level--;
    }

    public function getNumOfDirs() {
	return $this->numOfDirs;
    }

    public function getNumOfFiles() {
	return $this->numOfFiles;
    }

    public function getStartTime() {
	return $this->startTime;
    }

    public function getEndTime() {
	return $this->endTime;
    }
    
    public function setReindex($reindex){
	$this->reindex = $reindex;
    }
    
    public function getReindex($reindex){
	return $this->reindex;
    }

}
