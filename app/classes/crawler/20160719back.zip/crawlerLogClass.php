<?php
namespace App\Crawler;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
use Tracy\Debugger;
/**
 * Description of crawlerLogClass
 *
 * @author SukL
 */
abstract class crawlerLogClass {
    private $log;
     
    protected function insertToLog($text){
	Debugger::dump($this->log);
	$this->log .= $text;
    }
    
    public function getLog(){
	return $this->log;
    }
}
